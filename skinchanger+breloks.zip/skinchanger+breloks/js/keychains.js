document.querySelectorAll('.select-skin-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    const skinOption = this.closest('.skin-option');
    const team = skinOption.dataset.team;
    const weapon_defindex = skinOption.dataset.weapon_defindex;
    const paint = skinOption.dataset.paint;

    // AJAX-запит або інша логіка
    // Наприклад, відправка на сервер:
    fetch('/select_skin.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({team, weapon_defindex, paint})
    })
    .then(response => response.json())
    .then(data => {
      alert('Скін вибрано!');
    });
  });
});