<?php

if (!function_exists("Path")) {
    return;
}

$host = "localhost";
$dbname = "cs2";
$username = "root";
$password = "DeskDeskDesk##";
$port = 3306;

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;port=$port", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $err) {
    return true;  // Додано ";"
}
?>
