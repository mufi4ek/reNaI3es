                                                                    <?php
                                                                    ini_set('display_errors', 0);
                                                                    ini_set('display_startup_errors', 0);
                                                                    error_reporting(E_ALL);

                                                                    if(!function_exists("Path")) {
                                                                        return;
                                                                    }

                                                                    if (isset($_POST['save_keychain']) && isset($_POST['weapon_id']) && isset($_POST['keychain_id'])) {
                                                                        $weapon_id = intval($_POST['weapon_id']);
                                                                        $keychain_id = trim($_POST['keychain_id']);
                                                                        $x = trim($_POST['keychain_x']);
                                                                        $y = trim($_POST['keychain_y']);
                                                                        $z = trim($_POST['keychain_z']);
                                                                        $zrot = trim($_POST['keychain_zrot']);
                                                                        $keychain = $keychain_id . ';' . $x . ';' . $y . ';' . $z . ';' . $zrot;
                                                                        $steamid = $_SESSION['steamid'];
                                                                        $stmt = $pdo->prepare("UPDATE `wp_player_skins` SET `weapon_keychain` = ? WHERE `steamid` = ? AND `weapon_defindex` = ?");
                                                                        $stmt->execute([$keychain, $steamid, $weapon_id]);
                                                                        echo "<script>location.href='?category=keychains&weapon_id=$weapon_id';</script>";
                                                                        exit;
                                                                    }

                                                                    /*************/
                                                                    /* SteamInfo */
                                                                    /*************/

                                                                    try {
                                                                        $steamApiUserInfo = file_get_contents("http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=$SteamAPI_KEY&steamids=".$_SESSION['steamid']);
                                                                        $UserInfo = json_decode($steamApiUserInfo)->response->players[0];
                                                                    }catch(Exception $err) {
                                                                        header("Refresh:0;");
                                                                    }

                                                                    /*************/
                                                                    /* Languages */
                                                                    /*************/

                                                                    $langs = scandir('translation/');
                                                                    array_shift($langs);
                                                                    array_shift($langs);

                                                                    /**************/
                                                                    /* Categories */
                                                                    /**************/

                                                                    if($Website_UseCategories) {
                                                                        $weapon_type_select = [
                                                                        "null"  => '',
                                                                        "keychains" => ''
                                                                        ];

                                                                        if(isset($_POST['category'])) {
                                                                            if($_POST['category'] == 'none') {
                                                                                $_SESSION['category'] = null;
                                                                            }else {
                                                                                $_SESSION['category'] = $_POST['category'];
                                                                            }
                                                                            
                                                                            echo "<script>if ( window.history.replaceState ) {window.history.replaceState(null, null, window.location.href);}</script>";
                                                                            unset($_POST['category']);
                                                                        }

                                                                        if(isset($_SESSION['category'])) {
                                                                            $weapon_type_select[$_SESSION['category']] = "class='selected'";

                                                                            if($_SESSION['category'] == 'agents') {
                                                                                $choose_translate = str_replace('{{label}}', $translations->skins->categories->{$_SESSION['category']}->label, $translations->skins->choose_weapon);
                                                                            }else {
                                                                                $choose_translate = str_replace('{{label}}', $translations->skins->categories->{$_SESSION['category']}, $translations->skins->choose_weapon);
                                                                            }
                                                                        }else {
                                                                            $choose_translate = str_replace('{{label}}', $translations->skins->choose_weapon_default, $translations->skins->choose_weapon);
                                                                        }
                                                                    }

                                                                    ?>
                                                                    <!DOCTYPE html>
                                                                    <html lang="en">
                                                                    <head>
                                                                        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
                                                                        <style>
                                                                        .credit {
                                                                                display: flex;
                                                                                justify-content: space-between;
                                                                                align-items: center;
                                                                                padding: 1rem;
                                                                                background: #f8f9fa;
                                                                                border-top: 1px solid #dee2e6;
                                                                            }
                                                                            
                                                                            .main-button {
                                                                                display: inline-flex;
                                                                                align-items: center;
                                                                                gap: 8px;
                                                                                padding: 8px 16px;
                                                                                background-color: #4e73df;
                                                                                color: white !important;
                                                                                border-radius: 4px;
                                                                                font-weight: 500;
                                                                                text-decoration: none !important;
                                                                                transition: all 0.2s ease;
                                                                            }
                                                                            
                                                                            .main-button:hover {
                                                                                background-color: #2e59d9;
                                                                                transform: translateY(-2px);
                                                                                box-shadow: 0 4px 8px rgba(0,0,0,0.1);
                                                                            }
                                                                            
                                                                            /* Гарантуємо, що іконка відображається */
                                                                            .fa-solid {
                                                                                display: inline-block;
                                                                                font-size: 0.9em;
                                                                            }
                                                                        </style>
                                                                        <meta charset="UTF-8">
                                                                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                                                                        <link rel="shortcut icon" href="<?= GetPrefix(); ?>src/logo.png" type="image/x-icon">
                                                                        <link rel="stylesheet" href="<?= GetPrefix(); ?>css/main.css" type="text/css">
                                                                        <link rel="stylesheet" href="<?= GetPrefix(); ?>css/skins.css" type="text/css">
                                                                        <script src="https://cdn.jsdelivr.net/npm/three@0.153.0/build/three.min.js"></script>
                                                                        <script src="<?= GetPrefix(); ?>js/skins.js" defer></script>
                                                                        <title><?= $translations->website_name; ?> - Skins</title>
                                                                    </head>
                                                                    <body <?= $bodyStyle ?? "" ?>>
                                                                        <body<?= (isset($_SESSION['category']) && $_SESSION['category'] == 'keychains') ? ' class="category-keychains"' : '' ?> <?= $bodyStyle ?? "" ?>>

                                                                    <div id="loading">
                                                                        <span></span>
                                                                    </div>

                                                                    <div class="wrapper">
                                                                        <?php
                                                                        if($Website_UseCategories) {
                                                                        ?>
                                                                        <header class="categories">
                                                                            <ul>
                                                                                <li><button data-action="category" data-category="keychains" <?= $weapon_type_select['keychains']; ?>>
                                                                                    <img src="../src/t.png" alt="" class="trinket-icon">
                                                                                    <span class="helpbox">Keychains</span>
                                                                                </button></li>
                                                                                <h2><?= $choose_translate; ?></h2>
                                                                            </ul>
                                                                        </header>
                                                                        <?php
                                                                        }
                                                                        ?>
                                                                        
                                                                        <?php
                                                                    if(!$Website_UseCategories || (isset($_SESSION['category']) && $_SESSION['category'] == 'keychains')) {
                                                                        echo '<!-- DEBUG: keychains block active -->';
                                                                        // Отримуємо всі скіни користувача
                                                                        $state = $pdo->prepare("SELECT * FROM `wp_player_skins` WHERE `steamid` = ?");
                                                                        $state->execute([$_SESSION['steamid']]);
                                                                        $user_weapons = $state->fetchAll();

                                                                        // Отримуємо всі доступні брелки
                                                                        $keychains_list = json_decode(file_get_contents('src/data/keychains.json'), true);

                                                                        // Визначаємо вибрану зброю
                                                                        $selected_weapon_id = isset($_GET['weapon_id']) ? intval($_GET['weapon_id']) : ($user_weapons[0]['weapon_defindex'] ?? null);

                                                                        echo '<div style="display:flex;gap:32px;align-items:flex-start;">';

                                                                        // Ліва частина: форма для вибору брелка і позиції
                                                                        echo '<div style="flex:1; min-width:360px; margin-top: 150px;">';
                                                                        if ($selected_weapon_id !== null) {
                                                                            // Знаходимо поточний скин
                                                                            $current_weapon = null;
                                                                            foreach($user_weapons as $w) {
                                                                                if($w['weapon_defindex'] == $selected_weapon_id) {
                                                                                    $current_weapon = $w;
                                                                                    break;
                                                                                }
                                                                            }
                                                                            $current_keychain = $current_weapon['weapon_keychain'] ?? '';

                                                                            echo '<form method="post" class="keychain-form" style="display:flex;flex-direction:column;gap:12px;background:#f8f9fa;padding:24px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.04);">';
                                                                            echo '<h3>Налаштування брелка для: <span style="color:#0077ED">Зброя #'.$selected_weapon_id.'</span></h3>';

                                                                            // Вибір брелка
                                                                            echo '<label>Брелок: <select name="keychain_id" style="margin-left:8px;">';
                                                                            foreach($keychains_list as $kc) {
                                                                                $id = $kc['id'] ?? $kc['keychain_id'] ?? '';
                                                                                $selected = ($current_keychain && explode(';', $current_keychain)[0] == $id) ? 'selected' : '';
                                                                                echo '<option value="'.$id.'" '.$selected.'>'.$kc['name'].' ('.$id.')</option>';
                                                                            }
                                                                            echo '</select></label>';

                                                                            // Витягуємо координати
                                                                            $coords = explode(';', $current_keychain);
                                                                            $x = $coords[1] ?? '';
                                                                            $y = $coords[2] ?? '';
                                                                            $z = $coords[3] ?? '';
                                                                            $zrot = $coords[4] ?? '';

                                                                            echo '<label>X: <input type="text" name="keychain_x" value="'.htmlspecialchars($x).'" style="width:60px;"></label>';
                                                                            echo '<label>Y: <input type="text" name="keychain_y" value="'.htmlspecialchars($y).'" style="width:60px;"></label>';
                                                                            echo '<label>Z: <input type="text" name="keychain_z" value="'.htmlspecialchars($z).'" style="width:60px;"></label>';
                                                                            echo '<label>СТАВ НА 0: <input type="text" name="keychain_zrot" value="'.htmlspecialchars($zrot).'" style="width:60px;"></label>';
                                                                            

// Знайти вибраний брелок
$selected_keychain_id = $current_keychain ? explode(';', $current_keychain)[0] : '';
$selected_keychain = null;
foreach ($keychains_list as $kc) {
    $id = $kc['id'] ?? $kc['keychain_id'] ?? '';
    if ($id == $selected_keychain_id) {
        $selected_keychain = $kc;
        break;
    }
}
$keychain_img = $selected_keychain['image'] ?? '';

// Додаємо картинку
echo '<div id="keychain-preview" style="margin:12px 0;text-align:center;">';
if ($keychain_img) {
    echo '<img src="'.htmlspecialchars($keychain_img).'" alt="keychain" style="max-width:80px;max-height:80px;display:inline-block;">';
}
echo '</div>';

                                                                            echo '<input type="hidden" name="weapon_id" value="'.$selected_weapon_id.'">';
                                                                            echo '<button type="submit" name="save_keychain" class="main-button" style="margin-top:12px;">Зберегти</button>';
                                                                            echo '</form>';
                                                                        }
                                                                        echo '</div>';

                                                                        // Права частина: список зброї з брелками
                                                                        // --- Визначаємо allowed_weapon_ids та функцію GetWeaponTeam ---
$allowed_weapon_ids = [
    // Pistols
    1, 2, 3, 4, 30, 32, 36, 61, 63, 64,
    // SMG
    17, 19, 23, 24, 26, 33, 34,
    // Rifles
    7, 8, 10, 13, 16, 60, 39, 40, 54,
    // Shotguns
    25, 27, 29, 35,
    // Machine Guns
    14, 28,
    // Sniper Rifles
    9, 11, 38, 40,
    // Grenades (якщо треба)
    43, 44, 45, 46, 47, 48, 68, 69, 70,
    // Zeus
    31,
    // C4
    49,
];
function GetWeaponTeam($defindex) {
    $t_weapons = [7, 39]; // AK-47, SG553, ... (додайте свої)
    $ct_weapons = [60, 16]; // M4A1-S, M4A4, ... (додайте свої)
    if (in_array($defindex, $t_weapons)) return 'T';
    if (in_array($defindex, $ct_weapons)) return 'CT';
    return 'ALL';
}

// --- Фільтруємо тільки дозволені айді ---
$user_weapons_filtered = array_filter($user_weapons, function($weapon) use ($allowed_weapon_ids) {
    return in_array($weapon['weapon_defindex'], $allowed_weapon_ids);
});
$user_weapons_filtered = array_values($user_weapons_filtered);

// --- Вивід списку зброї у вертикальному скролл-боксі ---
echo '<div style="flex:1; min-width:700px; max-width:800px; margin-top: 150px;">';
echo '<h3 style="margin-bottom:16px;">Виберіть зброю</h3>';
echo '<div style="max-height: 520px; overflow-y: auto; border-radius: 10px; border: 1px solid #23243a; background: #18192b; box-shadow: 0 2px 8px rgba(0,0,0,0.10); padding: 18px;">';
echo '<ul class="skins-list" style="list-style:none;padding:0;margin:0;display:grid;grid-template-columns:repeat(4,1fr);gap:18px;">';
foreach($user_weapons_filtered as $weapon) {
    $skin_image = '';
    $skin_name = '';
    foreach ($full_skins as $skin) {
        if ($skin->weapon_defindex == $weapon['weapon_defindex'] && $skin->paint == $weapon['weapon_paint_id']) {
            $skin_image = $skin->image;
            $skin_name = $skin->paint_name ?? '';
            break;
        }
    }
    $is_selected = ($weapon['weapon_defindex'] == $selected_weapon_id);
    echo '<li>';
    echo '<a href="?category=stickers&weapon_id='.$weapon['weapon_defindex'].'" class="skin-btn'.($is_selected?' selected':'').'" class="skin-btn'.($is_selected?' selected':'').'" style="display:flex;flex-direction:column;align-items:center;gap:10px;padding:14px 8px;border-radius:10px;transition:background 0.2s;'.($is_selected?'background:#23243a;box-shadow:0 0 0 3px #2e59d9;':'background:#23243a;').'">';
    echo '<img src="'.htmlspecialchars($skin_image).'" alt="" style="width:100px;height:60px;object-fit:contain;background:#222;border-radius:8px;border:1px solid #333;box-shadow:0 2px 8px rgba(0,0,0,0.10);">';
    echo '<span style="font-size:16px;color:#fff;">#'.$weapon['weapon_defindex'].'</span>';
    if($skin_name) {
        echo '<span style="font-size:14px;color:#b0b4d1;text-align:center;display:block;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'.htmlspecialchars($skin_name).'</span>';
    }
    echo '</a>';
    echo '</li>';
}
echo '</ul>';
echo '</div>';
echo '</div>';


if(!$Website_UseCategories || (isset($_SESSION['category']) && $_SESSION['category'] == 'stickers')) {
    echo '<!-- DEBUG: stickers block active -->';
    // Отримуємо всі скіни користувача
    $state = $pdo->prepare("SELECT * FROM `wp_player_skins` WHERE `steamid` = ?");
    $state->execute([$_SESSION['steamid']]);
    $user_weapons = $state->fetchAll();

    // Всі доступні наліпки
    $stickers_list = json_decode(file_get_contents('src/data/stickers.json'), true);

    // Вибрана зброя
    $selected_weapon_id = isset($_GET['weapon_id']) ? intval($_GET['weapon_id']) : ($user_weapons[0]['weapon_defindex'] ?? null);

    echo '<div style="display:flex;gap:32px;align-items:flex-start;">';

    // Ліва частина: форми для кожної позиції наліпки
    echo '<div style="flex:1; min-width:360px; margin-top: 150px;">';
    if ($selected_weapon_id !== null) {
        // Знаходимо поточний скин
        $current_weapon = null;
        foreach($user_weapons as $w) {
            if($w['weapon_defindex'] == $selected_weapon_id) {
                $current_weapon = $w;
                break;
            }
        }

        // 4 позиції для наліпок (0-3)
        for ($i = 0; $i < 4; $i++) {
            $current_sticker = $current_weapon['weapon_sticker_'.$i] ?? '';
            $coords = explode(';', $current_sticker);
            $sticker_id = $coords[0] ?? '';
            $x = $coords[1] ?? '';
            $y = $coords[2] ?? '';
            $z = $coords[3] ?? '';
            $rot = $coords[4] ?? '';
            $scale = $coords[5] ?? '';

            echo '<form method="post" class="sticker-form" style="margin-bottom:24px;display:flex;flex-direction:column;gap:12px;background:#f8f9fa;padding:24px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.04);">';
            echo '<h3>Наліпка '.($i+1).'</h3>';

            // Вибір наліпки
            echo '<label>Наліпка: <select name="sticker_id" id="sticker-select-'.$i.'" style="margin-left:8px;">';
            foreach($stickers_list as $st) {
                $id = $st['id'] ?? '';
                $selected = ($sticker_id == $id) ? 'selected' : '';
                $img = htmlspecialchars($st['image'] ?? '');
                echo '<option value="'.$id.'" data-img="'.$img.'" '.$selected.'>'.$st['name'].' ('.$id.')</option>';
            }
            echo '</select></label>';

            echo '<label>X: <input type="text" name="sticker_x" value="'.htmlspecialchars($x).'" style="width:60px;" id="sticker-x-'.$i.'"></label>';
            echo '<label>Y: <input type="text" name="sticker_y" value="'.htmlspecialchars($y).'" style="width:60px;" id="sticker-y-'.$i.'"></label>';
            echo '<label>Z: <input type="text" name="sticker_z" value="'.htmlspecialchars($z).'" style="width:60px;" id="sticker-z-'.$i.'"></label>';
            echo '<label>Кут: <input type="text" name="sticker_rot" value="'.htmlspecialchars($rot).'" style="width:60px;"></label>';
            echo '<label>Scale: <input type="text" name="sticker_scale" value="'.htmlspecialchars($scale).'" style="width:60px;"></label>';

            // 3D preview (можна зробити окремий div для кожної позиції)
            echo '<div id="sticker-3d-preview-'.$i.'" style="width:200px;height:200px;background:#222;margin:12px auto;"></div>';

            echo '<input type="hidden" name="weapon_id" value="'.$selected_weapon_id.'">';
            echo '<input type="hidden" name="sticker_slot" value="'.$i.'">';
            echo '<button type="submit" name="save_sticker" class="main-button" style="margin-top:12px;">Зберегти наліпку</button>';
            echo '</form>';
        }
    }
    echo '</div>';

    // Права частина: список зброї
    // --- Визначаємо allowed_weapon_ids та функцію GetWeaponTeam ---
    $allowed_weapon_ids = [
        1, 2, 3, 4, 30, 32, 36, 61, 63, 64, 17, 19, 23, 24, 26, 33, 34, 7, 8, 10, 13, 16, 60, 39, 40, 54, 25, 27, 29, 35, 14, 28, 9, 11, 38, 40, 43, 44, 45, 46, 47, 48, 68, 69, 70, 31, 49,
    ];
    function GetWeaponTeam($defindex) {
        $t_weapons = [7, 39];
        $ct_weapons = [60, 16];
        if (in_array($defindex, $t_weapons)) return 'T';
        if (in_array($defindex, $ct_weapons)) return 'CT';
        return 'ALL';
    }

    // --- Фільтруємо тільки дозволені айді ---
    $user_weapons_filtered = array_filter($user_weapons, function($weapon) use ($allowed_weapon_ids) {
        return in_array($weapon['weapon_defindex'], $allowed_weapon_ids);
    });
    $user_weapons_filtered = array_values($user_weapons_filtered);

    // --- Вивід списку зброї ---
    echo '<div style="flex:1; min-width:700px; max-width:800px; margin-top: 150px;">';
    echo '<h3 style="margin-bottom:16px;">Виберіть зброю</h3>';
    echo '<div style="max-height: 520px; overflow-y: auto; border-radius: 10px; border: 1px solid #23243a; background: #18192b; box-shadow: 0 2px 8px rgba(0,0,0,0.10); padding: 18px;">';
    echo '<ul class="skins-list" style="list-style:none;padding:0;margin:0;display:grid;grid-template-columns:repeat(4,1fr);gap:18px;">';
    foreach($user_weapons_filtered as $weapon) {
        $skin_image = '';
        $skin_name = '';
        foreach ($full_skins as $skin) {
            if ($skin->weapon_defindex == $weapon['weapon_defindex'] && $skin->paint == $weapon['weapon_paint_id']) {
                $skin_image = $skin->image;
                $skin_name = $skin->paint_name ?? '';
                break;
            }
        }
        $is_selected = ($weapon['weapon_defindex'] == $selected_weapon_id);
        echo '<li>';
        echo '<a href="?category=stickers&weapon_id='.$weapon['weapon_defindex'].'" class="skin-btn'.($is_selected?' selected':'').'" style="display:flex;flex-direction:column;align-items:center;gap:10px;padding:14px 8px;border-radius:10px;transition:background 0.2s;'.($is_selected?'background:#23243a;box-shadow:0 0 0 3px #2e59d9;':'background:#23243a;').'">';
        echo '<img src="'.htmlspecialchars($skin_image).'" alt="" style="width:100px;height:60px;object-fit:contain;background:#222;border-radius:8px;border:1px solid #333;box-shadow:0 2px 8px rgba(0,0,0,0.10);">';
        echo '<span style="font-size:16px;color:#fff;">#'.$weapon['weapon_defindex'].'</span>';
        if($skin_name) {
            echo '<span style="font-size:14px;color:#b0b4d1;text-align:center;display:block;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'.htmlspecialchars($skin_name).'</span>';
        }
        echo '</a>';
        echo '</li>';
    }
    echo '</ul>';
    echo '</div>';
    echo '</div>';
}
                                                                    ?>
                                                                        <div class="container" <?= $Website_UseCategories ? 'style="margin-top: 100px;"':'' ?>>
                                                                            <div class="choose">
                                                                                <ul>
                                                                                    
                                                                                    <?php
                                                                                    // Player Skins
                                                                                    $state = $pdo->prepare("SELECT * FROM `wp_player_skins` WHERE `steamid` = ?");
                                                                                    $state->execute([$_SESSION['steamid']]);
                                                                                    $results = $state->fetchAll();
                                                                                    
                                                                                    $state = $pdo->prepare("SELECT * FROM `wp_player_knife` WHERE `steamid` = ?");
                                                                                    $state->execute([$_SESSION['steamid']]);
                                                                                    $savedknifes = $state->fetchAll();

                                                                                    $knife_t = false;
                                                                                    $knife_ct = false;
                                                                                    foreach($savedknifes as $saved) {
                                                                                        if($saved['weapon_team'] == 2) {
                                                                                            $knife_t = $saved;
                                                                                        }
                                                                                        if($saved['weapon_team'] == 3) {
                                                                                            $knife_ct = $saved;
                                                                                        }
                                                                                    }

                                                                                    $savedskins = [];
                                                                                    $savedskins_info = [];
                                                                                    foreach($results as $saved) {
                                                                                        if(!isset($savedskins[$saved['weapon_defindex']])) {
                                                                                            $savedskins[$saved['weapon_defindex']] = [];
                                                                                            $savedskins_info[$saved['weapon_defindex']] = [];
                                                                                        }
                                                                                        
                                                                                        array_push($savedskins[$saved['weapon_defindex']], $saved);
                                                                                        if(GetWeaponType($saved['weapon_defindex']) == 'gloves') {
                                                                                            foreach($gloves as $glove){
                                                                                                if($glove->weapon_defindex == $saved['weapon_defindex'] && $glove->paint == $saved['weapon_paint_id']) {
                                                                                                    array_push($savedskins_info[$saved['weapon_defindex']], $glove);
                                                                                                    break;
                                                                                                }
                                                                                            }
                                                                                        }else {
                                                                                            foreach($full_skins as $skin){
                                                                                                if($skin->weapon_defindex == $saved['weapon_defindex'] && $skin->paint == $saved['weapon_paint_id']) {
                                                                                                    array_push($savedskins_info[$saved['weapon_defindex']], $skin);
                                                                                                    break;
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }


                                                                                    $shownskins = [];
                                                                                    foreach($full_skins as $skin) {
                                                                                        if(in_array($skin->weapon_name, $shownskins)
                                                                                        || $Website_UseCategories && isset($_SESSION['category']) && GetWeaponType($skin->weapon_name) != $_SESSION['category']) {continue;}
                                                                                        array_push($shownskins, $skin->weapon_name);

                                                                                        if(isset($savedskins[$skin->weapon_defindex])) {
                                                                                            ?>
                                                                                            <li>
                                                                                                <button class='card <?= $skin->weapon_name == $knife_t['knife'] || $skin->weapon_name == $knife_ct['knife']?'selected':''; ?>' data-action='weapon_picked' data-weapon='<?= $skin->weapon_name; ?>'>
                                                                                                    <div class="imgbox">
                                                                                                        <?php
                                                                                                        foreach($savedskins_info[$skin->weapon_defindex] as $saved) {
                                                                                                        ?>
                                                                                                        <img src="<?= $saved->image; ?>" loading='lazy'>
                                                                                                        <?php
                                                                                                        }
                                                                                                        ?>
                                                                                                    </div>
                                                                                                    <span><?= explode(' | ', $skin->paint_name)[0]; ?></span>
                                                                                                    <div class="marks">
                                                                                                        <?php
                                                                                                        foreach($savedskins[$skin->weapon_defindex] as $saved) {
                                                                                                        if($saved['weapon_team'] == 2) {
                                                                                                        ?>
                                                                                                        <input type="radio" name="marks_<?= $skin->weapon_name; ?>" class="terrormark" oninput="ChangePreviewImage(this);" checked>
                                                                                                        <?php
                                                                                                        }else if($saved['weapon_team'] == 3) {
                                                                                                        ?>
                                                                                                        <input type="radio" name="marks_<?= $skin->weapon_name; ?>" class="counterterrormark" oninput="ChangePreviewImage(this);" <?= count($savedskins[$skin->weapon_defindex])<2?'checked':''; ?>>
                                                                                                        <?php
                                                                                                        }
                                                                                                        }
                                                                                                        ?>
                                                                                                    </div>
                                                                                                </button>
                                                                                            </li>
                                                                                            <?php
                                                                                            continue;
                                                                                        }
                                                                                        
                                                                                        ?>
                                                                                        <li>
                                                                                            <button class='card <?= !$knife_t && $skin->weapon_name == 'weapon_knife_default' || !$knife_ct && $skin->weapon_name == 'weapon_knife_default'?'selected':''; ?>' data-action='weapon_picked' data-weapon='<?= $skin->weapon_name; ?>'>
                                                                                                <div class="imgbox">
                                                                                                    <img src="<?= $skin->image; ?>" loading='lazy'>
                                                                                                </div>
                                                                                                <span><?= explode(' | ', $skin->paint_name)[0]; ?></span>
                                                                                                <div class="marks"></div>
                                                                                            </button>
                                                                                        </li>
                                                                                        <?php
                                                                                    }

                                                                                    ?>

                                                                                    <?php
                                                                                    // Gloves
                                                                                    $showngloves = [];
                                                                                    foreach($gloves as $glove) {
                                                                                        if(in_array($glove->weapon_defindex, $showngloves) ||
                                                                                        $Website_UseCategories && isset($_SESSION['category']) && $_SESSION['category'] != 'gloves') {continue;}
                                                                                        array_push($showngloves, $glove->weapon_defindex);

                                                                                        $state = $pdo->prepare("SELECT * FROM `wp_player_gloves` WHERE `steamid` = ?");
                                                                                        $state->execute([$_SESSION['steamid']]);
                                                                                        $savedgloves = $state->fetchAll();
                                                                                        $gloves_selected_t = false;
                                                                                        $gloves_selected_ct = false;

                                                                                        foreach($savedgloves as $glovesaved) {
                                                                                            if($glovesaved['weapon_team'] == 2) {
                                                                                                $gloves_selected_t = $glovesaved['weapon_defindex'];
                                                                                            }else if($glovesaved['weapon_team'] == 3) {
                                                                                                $gloves_selected_ct = $glovesaved['weapon_defindex'];
                                                                                            }
                                                                                        }

                                                                                        if(isset($savedskins[$glove->weapon_defindex])) {
                                                                                            ?>
                                                                                            <li>
                                                                                                <button class='card <?= $gloves_selected_t == $glove->weapon_defindex || $gloves_selected_ct == $glove->weapon_defindex?'selected':''; ?>' data-action='weapon_picked' data-weapon='<?= $glove->weapon_defindex; ?>'>
                                                                                                    <div class="imgbox">
                                                                                                        <?php
                                                                                                        foreach($savedskins_info[$glove->weapon_defindex] as $saved) {
                                                                                                        ?>
                                                                                                        <img src="<?= $saved->image; ?>" loading='lazy'>
                                                                                                        <?php
                                                                                                        }
                                                                                                        ?>
                                                                                                    </div>
                                                                                                    <span><?= explode(' | ', $glove->paint_name)[0]; ?></span>
                                                                                                    <div class="marks">
                                                                                                        <?php
                                                                                                        foreach($savedskins[$glove->weapon_defindex] as $saved) {
                                                                                                        if($saved['weapon_team'] == 2) {
                                                                                                        ?>
                                                                                                        <input type="radio" name="marks_<?= $glove->weapon_defindex; ?>" class="terrormark" oninput="ChangePreviewImage(this);" checked>
                                                                                                        <?php
                                                                                                        }else if($saved['weapon_team'] == 3) {
                                                                                                        ?>
                                                                                                        <input type="radio" name="marks_<?= $glove->weapon_defindex; ?>" class="counterterrormark" oninput="ChangePreviewImage(this);" <?= count($savedskins[$glove->weapon_defindex])<2?'checked':''; ?>>
                                                                                                        <?php
                                                                                                        }
                                                                                                        }
                                                                                                        ?>
                                                                                                    </div>
                                                                                                </button>
                                                                                            </li>
                                                                                            <?php
                                                                                            continue;
                                                                                        }

                                                                                        ?>
                                                                                        <li>
                                                                                            <button class='card <?= !$gloves_selected_ct && $glove->weapon_defindex == 'gloves_default' || !$gloves_selected_t && $glove->weapon_defindex == 'gloves_default'?'selected':''; ?>' data-action='weapon_picked' data-weapon='<?= $glove->weapon_defindex; ?>'>
                                                                                                <div class="imgbox">
                                                                                                    <img src="<?= $glove->image; ?>" loading='lazy'>
                                                                                                </div>
                                                                                                <span><?= explode(' | ', $glove->paint_name)[0]; ?></span>
                                                                                                <div class="marks">
                                                                                                    <?php
                                                                                                    if($glove->weapon_defindex == 'gloves_default') {
                                                                                                        if(!$gloves_selected_t) {
                                                                                                            ?>
                                                                                                            <input type="radio" name="marks_<?= $glove->weapon_defindex; ?>" class="terrormark" checked>
                                                                                                            <?php
                                                                                                        }
                                                                                                        if(!$gloves_selected_ct) {
                                                                                                            ?>
                                                                                                            <input type="radio" name="marks_<?= $glove->weapon_defindex; ?>" class="counterterrormark" <?= $gloves_selected_t?'checked':''; ?>>
                                                                                                            <?php
                                                                                                        }
                                                                                                    }
                                                                                                    ?>
                                                                                                </div>
                                                                                            </button>
                                                                                        </li>
                                                                                        <?php
                                                                                    }
                                                                                    ?>

                                                                                    <?php
                                                                                    // Agents
                                                                                    if(!$Website_UseCategories || !isset($_SESSION['category']) || $_SESSION['category'] == 'agents') {
                                                                                        $state = $pdo->prepare("SELECT * FROM `wp_player_agents` WHERE `steamid` = ?");
                                                                                        $state->execute([$_SESSION['steamid']]);
                                                                                        $savedagents = $state->fetch();

                                                                                        foreach($agents as $agent) {
                                                                                            if($savedagents && $savedagents['agent_t']) {
                                                                                                if($agent->team == 2 && $agent->model == $savedagents['agent_t']) {
                                                                                                    ?>
                                                                                                    <li>
                                                                                                        <button class='card' data-action='agent_picked' data-team='terrorist'>
                                                                                                            <div class="imgbox">
                                                                                                                <img src="<?= $agent->image; ?>" loading='lazy'>
                                                                                                            </div>
                                                                                                            <span><?= $translations->skins->categories->agents->t; ?></span>
                                                                                                        </button>
                                                                                                    </li>
                                                                                                    <?php
                                                                                                }
                                                                                            }else {
                                                                                                if($agent->team == 2 && $agent->model == 'default') {
                                                                                                    ?>
                                                                                                    <li>
                                                                                                        <button class='card' data-action='agent_picked' data-team='terrorist'>
                                                                                                            <div class="imgbox">
                                                                                                                <img src="<?= $agent->image; ?>" loading='lazy'>
                                                                                                            </div>
                                                                                                            <span><?= $translations->skins->categories->agents->t; ?></span>
                                                                                                        </button>
                                                                                                    </li>
                                                                                                    <?php
                                                                                                }
                                                                                            }

                                                                                            if($savedagents && $savedagents['agent_ct']) {
                                                                                                if($agent->team == 3 && $agent->model == $savedagents['agent_ct']) {
                                                                                                    ?>
                                                                                                    <li>
                                                                                                        <button class='card' data-action='agent_picked' data-team='counter-terrorist'>
                                                                                                            <div class="imgbox">
                                                                                                                <img src="<?= $agent->image; ?>" loading='lazy'>
                                                                                                            </div>
                                                                                                            <span><?= $translations->skins->categories->agents->ct; ?></span>
                                                                                                        </button>
                                                                                                    </li>
                                                                                                    <?php
                                                                                                }
                                                                                            }else {
                                                                                                if($agent->team == 3 && $agent->model == 'default') {
                                                                                                    ?>
                                                                                                    <li>
                                                                                                        <button class='card' data-action='agent_picked' data-team='counter-terrorist'>
                                                                                                            <div class="imgbox">
                                                                                                                <img src="<?= $agent->image; ?>" loading='lazy'>
                                                                                                            </div>
                                                                                                            <span><?= $translations->skins->categories->agents->ct; ?></span>
                                                                                                        </button>
                                                                                                    </li>
                                                                                                    <?php
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    ?>

                                                                                    <?php
                                                                                    // Music
                                                                                    if(!$Website_UseCategories || !isset($_SESSION['category']) || $_SESSION['category'] == 'mvp') {
                                                                                    $state = $pdo->prepare("SELECT * FROM `wp_player_music` WHERE `steamid` = ?");
                                                                                    $state->execute([$_SESSION['steamid']]);
                                                                                    $savedmusic = $state->fetchAll();

                                                                                    $music_t = false;
                                                                                    $music_ct = false;
                                                                                    foreach($savedmusic as $saved) {
                                                                                        foreach($songs as $song) {
                                                                                            if($song->id == $saved['music_id']) {
                                                                                                if($saved['weapon_team'] == 2) {
                                                                                                    $music_t = $song;
                                                                                                }else if($saved['weapon_team'] == 3) {
                                                                                                    $music_ct = $song;
                                                                                                }
                                                                                                break;
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    if(count($savedmusic) > 0) {
                                                                                        ?>
                                                                                        <li>
                                                                                            <button class='card' data-action='weapon_picked' data-weapon='mvp'>
                                                                                                <div class="imgbox">
                                                                                                    <?php
                                                                                                    if($music_t) {
                                                                                                    ?>
                                                                                                    <img src="<?= $music_t->image; ?>">
                                                                                                    <?php
                                                                                                    }
                                                                                                    if($music_ct) {
                                                                                                    ?>
                                                                                                    <img src="<?= $music_ct->image; ?>">
                                                                                                    <?php
                                                                                                    }
                                                                                                    ?>
                                                                                                </div>
                                                                                                <span><?= $translations->skins->categories->mvp; ?></span>
                                                                                                <div class="marks">
                                                                                                    <?php
                                                                                                    if(count($savedmusic) > 1) {
                                                                                                    ?>
                                                                                                    <input type="radio" name="marks_music" class="terrormark" oninput="ChangePreviewImage(this);" checked>
                                                                                                    <input type="radio" name="marks_music" class="counterterrormark" oninput="ChangePreviewImage(this);">
                                                                                                    <?php
                                                                                                    }
                                                                                                    ?>
                                                                                                </div>
                                                                                            </button>
                                                                                        </li>
                                                                                        <?php
                                                                                    }else {
                                                                                        ?>
                                                                                        <li>
                                                                                            <button class='card' data-action='weapon_picked' data-weapon='mvp'>
                                                                                                <div class="imgbox">
                                                                                                    <img src="<?= $songs[0]->image; ?>" loading='lazy'>
                                                                                                </div>
                                                                                                <span><?= $translations->skins->categories->mvp; ?></span>
                                                                                            </button>
                                                                                        </li>
                                                                                        <?php
                                                                                    }
                                                                                    }
                                                                                    ?>
                                                                                    
                                                                                    <?php
                                                                                    }
                                                                                    ?>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <footer>
                                                                        <div class="wrapper">
                                                                            <a class="info" href="https://steamcommunity.com/profiles/<?= $_SESSION['steamid']; ?>" target="_blank">
                                                                                <img src="<?= $UserInfo->avatarfull ?>" alt="name">
                                                                                <p><?= str_replace('{{name}}', "<strong>$UserInfo->personaname</strong>", $translations->skins->footer->signedin); ?></p>
                                                                            </a>
                                                                            <div class="credit">
                                                                            <a href="/" class="main-button">
                                                                                <i class="fa-solid fa-house-chimney"></i>
                                                                                Головна
                                                                            </a>
                                                                        </div>
                                                                            <div class="actions">
                                                                                <div class="settings">
                                                                                    <svg viewBox="0 0 48 48" data-action="toggle_menu"><path d="M0 0h48v48H0z" fill="none"/><path d="M38.86 25.95c.08-.64.14-1.29.14-1.95s-.06-1.31-.14-1.95l4.23-3.31c.38-.3.49-.84.24-1.28l-4-6.93c-.25-.43-.77-.61-1.22-.43l-4.98 2.01c-1.03-.79-2.16-1.46-3.38-1.97L29 4.84c-.09-.47-.5-.84-1-.84h-8c-.5 0-.91.37-.99.84l-.75 5.3c-1.22.51-2.35 1.17-3.38 1.97L9.9 10.1c-.45-.17-.97 0-1.22.43l-4 6.93c-.25.43-.14.97.24 1.28l4.22 3.31C9.06 22.69 9 23.34 9 24s.06 1.31.14 1.95l-4.22 3.31c-.38.3-.49.84-.24 1.28l4 6.93c.25.43.77.61 1.22.43l4.98-2.01c1.03.79 2.16 1.46 3.38 1.97l.75 5.3c.08.47.49.84.99.84h8c.5 0 .91-.37.99-.84l.75-5.3c1.22-.51 2.35-1.17 3.38-1.97l4.98 2.01c.45.17.97 0 1.22-.43l4-6.93c.25-.43.14-.97-.24-1.28l-4.22-3.31zM24 31c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z"/></svg>
                                                                                    <div class="items">
                                                                                        <ul>
                                                                                            <?php
                                                                                            if($Website_Settings['language']) {
                                                                                            ?>
                                                                                            <button data-action="language_select" data-langs='<?= json_encode($langs); ?>'>
                                                                                                <svg viewBox="0 0 20 20"><path d="M10,0 C4.5,0 0,4.5 0,10 C0,15.5 4.5,20 10,20 C15.5,20 20,15.5 20,10 C20,4.5 15.5,0 10,0 L10,0 Z M16.9,6 L14,6 C13.7,4.7 13.2,3.6 12.6,2.4 C14.4,3.1 16,4.3 16.9,6 L16.9,6 Z M10,2 C10.8,3.2 11.5,4.5 11.9,6 L8.1,6 C8.5,4.6 9.2,3.2 10,2 L10,2 Z M2.3,12 C2.1,11.4 2,10.7 2,10 C2,9.3 2.1,8.6 2.3,8 L5.7,8 C5.6,8.7 5.6,9.3 5.6,10 C5.6,10.7 5.7,11.3 5.7,12 L2.3,12 L2.3,12 Z M3.1,14 L6,14 C6.3,15.3 6.8,16.4 7.4,17.6 C5.6,16.9 4,15.7 3.1,14 L3.1,14 Z M6,6 L3.1,6 C4.1,4.3 5.6,3.1 7.4,2.4 C6.8,3.6 6.3,4.7 6,6 L6,6 Z M10,18 C9.2,16.8 8.5,15.5 8.1,14 L11.9,14 C11.5,15.4 10.8,16.8 10,18 L10,18 Z M12.3,12 L7.7,12 C7.6,11.3 7.5,10.7 7.5,10 C7.5,9.3 7.6,8.7 7.7,8 L12.4,8 C12.5,8.7 12.6,9.3 12.6,10 C12.6,10.7 12.4,11.3 12.3,12 L12.3,12 Z M12.6,17.6 C13.2,16.5 13.7,15.3 14,14 L16.9,14 C16,15.7 14.4,16.9 12.6,17.6 L12.6,17.6 Z M14.4,12 C14.5,11.3 14.5,10.7 14.5,10 C14.5,9.3 14.4,8.7 14.4,8 L17.8,8 C18,8.6 18.1,9.3 18.1,10 C18.1,10.7 18,11.4 17.8,12 L14.4,12 L14.4,12 Z"/></svg>
                                                                                                <div>
                                                                                                    <span><?= $translations->skins->footer->settings->language ?></span>
                                                                                                    <svg viewBox="0 0 512 512"><polygon points="160,115.4 180.7,96 352,256 180.7,416 160,396.7 310.5,256 "/></svg>
                                                                                                </div>
                                                                                            </button>
                                                                                            <?php
                                                                                            }
                                                                                            if($Website_Settings['theme']) {
                                                                                            ?>
                                                                                            <button data-action="color_select" data-translations='<?= json_encode($translations->skins->footer->settings->theme); ?>'>
                                                                                                <svg viewBox="0 0 20 20"><path d="M9 20v-1.7l.01-.24L15.07 12h2.94c1.1 0 1.99.89 1.99 2v4a2 2 0 0 1-2 2H9zm0-3.34V5.34l2.08-2.07a1.99 1.99 0 0 1 2.82 0l2.83 2.83a2 2 0 0 1 0 2.82L9 16.66zM0 1.99C0 .9.89 0 2 0h4a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2zM4 17a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/></svg>
                                                                                                <div>
                                                                                                    <span><?= $translations->skins->footer->settings->theme->label ?></span>
                                                                                                    <svg viewBox="0 0 512 512"><polygon points="160,115.4 180.7,96 352,256 180.7,416 160,396.7 310.5,256 "/></svg>
                                                                                                </div>
                                                                                            </button>
                                                                                            <?php
                                                                                            }
                                                                                            ?>
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>
                                                                                <button class="main-btn" onclick="ToggleLoading();location.href='<?= GetPrefix(); ?>signout';"><?= $translations->skins->footer->sign_out ?>
                                                                                    <svg viewBox="0 0 24 24"><path d="M12,10c1.1,0,2-0.9,2-2V4c0-1.1-0.9-2-2-2s-2,0.9-2,2v4C10,9.1,10.9,10,12,10z"/><path d="M19.1,4.9L19.1,4.9c-0.3-0.3-0.6-0.4-1.1-0.4c-0.8,0-1.5,0.7-1.5,1.5c0,0.4,0.2,0.8,0.4,1.1l0,0c0,0,0,0,0,0c0,0,0,0,0,0    c1.3,1.3,2,3,2,4.9c0,3.9-3.1,7-7,7s-7-3.1-7-7c0-1.9,0.8-3.7,2.1-4.9l0,0C7.3,6.8,7.5,6.4,7.5,6c0-0.8-0.7-1.5-1.5-1.5    c-0.4,0-0.8,0.2-1.1,0.4l0,0C3.1,6.7,2,9.2,2,12c0,5.5,4.5,10,10,10s10-4.5,10-10C22,9.2,20.9,6.7,19.1,4.9z"/></svg>
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                    </footer>

                                                                    <script>
document.addEventListener('DOMContentLoaded', function() {
    const preview = document.getElementById('sticker-3d-preview');
    if (!preview) return;

    // Three.js базова сцена
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(200, 200);
    preview.appendChild(renderer.domElement);

    // Простий box як mockup зброї
    const geometry = new THREE.BoxGeometry(1, 0.3, 0.2);
    const material = new THREE.MeshStandardMaterial({ color: 0x555577 });
    const weapon = new THREE.Mesh(geometry, material);
    scene.add(weapon);

    // Sticker plane
    function getStickerImg() {
        const sel = document.getElementById('sticker-select');
        return sel.options[sel.selectedIndex].getAttribute('data-img') || '';
    }
    let stickerTexture = new THREE.TextureLoader().load(getStickerImg());
    let stickerMat = new THREE.MeshBasicMaterial({ map: stickerTexture, transparent: true });
    const sticker = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.3), stickerMat);
    scene.add(sticker);

    // Світло
    scene.add(new THREE.AmbientLight(0xffffff, 1));
    camera.position.set(2, 1, 2);
    camera.lookAt(0, 0, 0);

    // Update sticker position
    function updateSticker() {
        sticker.position.set(
            parseFloat(document.getElementById('sticker-x').value || 0),
            parseFloat(document.getElementById('sticker-y').value || 0),
            parseFloat(document.getElementById('sticker-z').value || 0)
        );
    }
    document.getElementById('sticker-x').addEventListener('input', updateSticker);
    document.getElementById('sticker-y').addEventListener('input', updateSticker);
    document.getElementById('sticker-z').addEventListener('input', updateSticker);

    // Update sticker texture on select change
    document.getElementById('sticker-select').addEventListener('change', function() {
        stickerTexture = new THREE.TextureLoader().load(getStickerImg());
        sticker.material.map = stickerTexture;
        sticker.material.needsUpdate = true;
    });

    updateSticker();

    // Render loop
    function animate() {
        requestAnimationFrame(animate);
        weapon.rotation.y += 0.01;
        renderer.render(scene, camera);
    }
    animate();
});
</script>

                                                                    </body>
                                                                    </html>