import DraggableItem from './DraggableItem';

const STICKERS = [
  { id: 1, name: 'Sticker 1', texture: 'https://raw.githubusercontent.com/Nereziel/cs2-WeaponPaints/main/website/img/skins/sticker-1.png' },
  // ...
];

const TRINKETS = [
  { id: 1, name: 'Keychain', model: '' },
  // ...
];

export default function InventoryPanel() {
  return (
    <div className="inventory-panel">
      <h3>Наліпки</h3>
      <div className="items-grid">
        {STICKERS.map((item) => (
          <DraggableItem 
            key={item.id} 
            type="STICKER" 
            texture={item.texture} 
            name={item.name} 
          />
        ))}
      </div>
      
      <h3>Брелоки</h3>
      <div className="items-grid">
        {TRINKETS.map((item) => (
          <DraggableItem 
            key={item.id} 
            type="TRINKET" 
            texture={item.texture} 
            name={item.name} 
          />
        ))}
      </div>
    </div>
  );
}