const STORAGE_KEY = 'weapon_customizations';

export const saveCustomization = (weaponId, data) => {
  const allData = JSON.parse(localStorage.getItem(STORAGE_KEY)) || {};
  allData[weaponId] = data;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(allData));
};

export const loadCustomization = (weaponId) => {
  const data = JSON.parse(localStorage.getItem(STORAGE_KEY)) || {};
  return data[weaponId] || null;
};

// Конвертація у формат LielXD
export const convertToLielXD = (stickers) => {
  return stickers.map(sticker => ({
    position: {
      x: Math.round(sticker.position.x * 100),
      y: Math.round(sticker.position.y * 100),
      z: Math.round(sticker.position.z * 100)
    },
    texture: sticker.texture
  }));
};