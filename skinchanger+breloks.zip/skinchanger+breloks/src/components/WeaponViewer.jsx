import { useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, useGLTF, Decal } from '@react-three/drei';
import { useDrag } from 'react-dnd';

// Завантаження моделі зброї
function WeaponModel({ position, rotation, stickers, trinkets }) {
  const { nodes, materials } = useGLTF('/assets/models/weapon.glb');
  const [hovered, setHovered] = useState(null);
  
  return (
    <group position={position} rotation={rotation}>
      <mesh 
        geometry={nodes.weapon.geometry} 
        material={materials.metal}
        onPointerOver={(e) => setHovered(e.faceIndex)}
        onPointerOut={() => setHovered(null)}
      >
        {stickers.map((sticker, idx) => (
          <Decal
            key={idx}
            position={sticker.position}
            rotation={sticker.rotation}
            scale={sticker.scale}
            map={useTexture(sticker.texture)}
          />
        ))}
      </mesh>
      
      {trinkets.map((trinket, idx) => (
        <TrinketModel key={idx} {...trinket} />
      ))}
    </group>
  );
}

// Обробник перетягування на модель
function DropTarget({ onDrop }) {
  const { scene } = useThree();
  const raycaster = useRef(new THREE.Raycaster());
  
  useFrame(({ mouse }) => {
    raycaster.current.setFromCamera(mouse, camera);
    const intersects = raycaster.current.intersectObjects(scene.children, true);
    if (intersects.length > 0) {
      // Підсвітка області
    }
  });
  
  const [, drop] = useDrop({
    accept: ['STICKER', 'TRINKET'],
    drop: (item, monitor) => {
      const offset = monitor.getClientOffset();
      const intersect = raycaster.current.intersectObjects(scene.children, true)[0];
      if (intersect) {
        onDrop(item, {
          position: intersect.point,
          normal: intersect.face.normal,
          uv: intersect.uv
        });
      }
    }
  });
  
  return <group ref={drop} />;
}

export default function WeaponViewer() {
  const [stickers, setStickers] = useState([]);
  const [trinkets, setTrinkets] = useState([]);
  
  const handleDrop = (item, position) => {
    if (item.type === 'STICKER') {
      setStickers([...stickers, {
        texture: item.texture,
        position: position.position,
        rotation: new THREE.Euler().setFromNormal(position.normal),
        scale: [0.1, 0.1, 0.1]
      }]);
    }
    if (item.type === 'TRINKET') {
      setStickers([...trinkets, {
        texture: item.texture,
        position: position.position,
        rotation: new THREE.Euler().setFromNormal(position.normal),
        scale: [0.1, 0.1, 0.1]
      }]);
    }
  };
  
  return (
    <Canvas camera={{ position: [0, 0, 1.5] }}>
      <ambientLight intensity={0.5} />
      <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} />
      <WeaponModel stickers={stickers} trinkets={trinkets} />
      <DropTarget onDrop={handleDrop} />
      <OrbitControls enableZoom={true} />
    </Canvas>
  );
}