import { useDrag } from 'react-dnd';

export default function DraggableItem({ type, texture, name }) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: type,
    item: { type, texture, name },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }));

  return (
    <div
      ref={drag}
      style={{
        opacity: isDragging ? 0.5 : 1,
        cursor: 'grab',
        width: 64,
        height: 64,
        background: `url(${texture}) center/contain no-repeat`
      }}
    />
  );
}