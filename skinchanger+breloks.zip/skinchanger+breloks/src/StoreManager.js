// src/utils/StoreManager.js
import { saveAs } from 'file-saver'; // Додати пакет: npm install file-saver

export const saveCustomization = (weaponId, data) => {
  /* ... існуюча логіка збереження ... */
};

export const loadCustomization = (weaponId) => {
  /* ... існуюча логіка завантаження ... */
};

// Конвертація 3D координат → 2D для LielXD
export const convertToLielXD = (items) => {
  return items.map(item => ({
    x: Math.round(item.screenPosition.x),
    y: Math.round(item.screenPosition.y),
    rotation: Math.round(item.rotation || 0)
  }));
};

// Нова функція експорту
export const exportWeaponData = (weaponId) => {
  const data = loadCustomization(weaponId);
  
  if (!data) {
    alert('Немає даних для експорту');
    return;
  }

  const lielXDData = {
    stickerPositions: convertToLielXD(data.stickers),
    trinketPosition: data.trinket 
      ? convertToLielXD([data.trinket])[0] 
      : null
  };

  const blob = new Blob(
    [JSON.stringify(lielXDData, null, 2)], 
    { type: 'application/json' }
  );
  
  saveAs(blob, `${weaponId}_customization.json`);
};