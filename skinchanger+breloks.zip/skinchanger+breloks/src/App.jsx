// src/App.jsx
import React, { useState } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import WeaponViewer from './components/WeaponViewer';
import InventoryPanel from './components/InventoryPanel';
import { exportWeaponData } from './utils/StoreManager';
import WeaponSelector from './components/WeaponSelector'; // Додатковий компонент

export default function App() {
  const [currentWeapon, setCurrentWeapon] = useState('ak47');
  
  return (
    <DndProvider backend={HTML5Backend}>
      <div className="app-container">
        <header>
          <h1>CS2 Weapon Customizer</h1>
          <WeaponSelector 
            value={currentWeapon} 
            onChange={setCurrentWeapon}
          />
        </header>
        
        <div className="main-content">
          <WeaponViewer weaponId={currentWeapon} />
          <InventoryPanel />
        </div>
        
        <div className="export-section">
          <button 
            onClick={() => exportWeaponData(currentWeapon)}
            className="export-btn"
          >
            <i className="fa fa-download"></i> Export to LielXD
          </button>
        </div>
      </div>
    </DndProvider>
  );
} 