<?php

if(!function_exists("Path")) {
    return;
}

/*************/
/* SteamInfo */
/*************/

try {
    $steamApiUserInfo = file_get_contents("http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=$SteamAPI_KEY&steamids=".$_SESSION['steamid']);
    $UserInfo = json_decode($steamApiUserInfo)->response->players[0];
}catch(Exception $err) {
    header("Refresh:0;");
}

/*************/
/* Languages */
/*************/

$langs = scandir('translation/');
array_shift($langs);
array_shift($langs);

/*******************/
/* Selected weapon */
/*******************/

$selectedweapon = Path(1);
$selectedweapon_type = GetWeaponType($selectedweapon);

if(!$selectedweapon_type) {
    header('Location: '.GetPrefix());
    exit;
}

$saved_ct = false;
$saved_t = false;

$current_ct = false;
$current_t = false;

$weapon_info = [];
switch($selectedweapon_type) {
    case 'gloves':
        $state = $pdo->prepare("SELECT * FROM `wp_player_gloves` WHERE `steamid` = ? AND `weapon_defindex` = ?");
        $state->execute([$_SESSION['steamid'], $selectedweapon]);
        $savedgloves = $state->fetchAll();

        foreach($savedgloves as $saved) {
            if($saved['weapon_team'] == 2) {
                $saved_t = $saved;
            }
            if($saved['weapon_team'] == 3) {
                $saved_ct = $saved;
            }
        }

        $state = $pdo->prepare("SELECT * FROM `wp_player_skins` WHERE `steamid` = ? AND `weapon_defindex` = ?");
        $state->execute([$_SESSION['steamid'], $selectedweapon]);
        $savedskins = $state->fetchAll();

        $temp_t = false;
        $temp_ct = false;
        foreach($savedskins as $saved) {
            if($saved['weapon_team'] == 2) {
                $temp_t = $saved;
            }
            if($saved['weapon_team'] == 3) {
                $temp_ct = $saved;
            }
        }

        foreach($gloves as $glove) {
            if(!$temp_t && !$temp_ct) {
                if($glove->weapon_defindex == $selectedweapon) {
                    $current_t = $glove;
                    break;
                }

                continue;
            }

            if($temp_t && $glove->weapon_defindex == $temp_t['weapon_defindex'] && $glove->paint == $temp_t['weapon_paint_id']) {
                $current_t = $glove;
            }
            if($temp_ct && $glove->weapon_defindex == $temp_ct['weapon_defindex'] && $glove->paint == $temp_ct['weapon_paint_id']) {
                $current_ct = $glove;
            }
        }

        $weapon_info['img'] = [];
        if($current_t) {
            $weapon_info['name'] = explode(' | ', $current_t->paint_name)[0];
            array_push($weapon_info['img'], $current_t->image);
        }
        if($current_ct) {
            if(!isset($weapon_info['name'])) {
                $weapon_info['name'] = explode(' | ', $current_ct->paint_name)[0];
            }
            array_push($weapon_info['img'], $current_ct->image);
        }
        break;
    case 'mvp':
        $state = $pdo->prepare("SELECT * FROM `wp_player_music` WHERE `steamid` = ?");
        $state->execute([$_SESSION['steamid']]);
        $savedmusic = $state->fetchAll();

        foreach($savedmusic as $saved) {
            if($saved['weapon_team'] == 2) {
                $saved_t = $saved;
            }
            if($saved['weapon_team'] == 3) {
                $saved_ct = $saved;
            }
        }

        foreach($songs as $song) {
            if(!$saved_t && !$saved_ct) {
                if($song->id == 0) {$current_t = $song;break;}
                continue;
            }
            if($saved_t && $song->id == $saved_t['music_id']) {
                $current_t = $song;
            }
            if($saved_ct && $song->id == $saved_ct['music_id']) {
                $current_ct = $song;
            }
        }

        $weapon_info['img'] = [];

        if($current_t) {
            $weapon_info['name'] = $current_t->name;
            array_push($weapon_info['img'], $current_t->image);
        }
        if($current_ct) {
            if(!isset($weapon_info['name'])) {
                $weapon_info['name'] = $current_ct->name;
            }
            array_push($weapon_info['img'], $current_ct->image);
        }

        break;
    case 'agents':
        $state = $pdo->prepare("SELECT * FROM `wp_player_agents` WHERE `steamid` = ?");
        $state->execute([$_SESSION['steamid']]);
        $savedagents = $state->fetch();

        if($savedagents && isset($savedagents['agent_t'])) {
            $saved_t = $savedagents['agent_t'];
        }
        if($savedagents && isset($savedagents['agent_ct'])) {
            $saved_ct = $savedagents['agent_ct'];
        }

        foreach($agents as $agent) {
            if($selectedweapon == 'terrorist' && $agent->team != 2 || $selectedweapon == 'counter-terrorist' && $agent->team != 3) {continue;}

            if($selectedweapon == 'terrorist' && !$saved_t && $agent->model == 'default' && $agent->team == 2) {
                $current_t = $agent;
                break;
            }
            if($selectedweapon == 'counter-terrorist' && !$saved_ct && $selectedweapon == 'counter-terrorist' && $agent->model == 'default' && $agent->team == 3) {
                $current_t = $agent;
                break;
            }

            if($selectedweapon == 'terrorist' && $agent->model == $saved_t) {
                $current_t = $agent;
            }else if($selectedweapon == 'counter-terrorist' && $agent->model == $saved_ct) {
                $current_t = $agent;
            }
        }

        if($current_t) {
            $weapon_info['name'] = $current_t->agent_name;
            $weapon_info['img'] = [$current_t->image];
        }

        break;
    default:
        foreach($full_skins as $skin) {
            if($skin->weapon_name != $selectedweapon || $skin->paint != 0) {continue;}

            $current_t = $skin;
            break;
        }

        $state = $pdo->prepare("SELECT * FROM `wp_player_skins` WHERE `steamid` = ? AND `weapon_defindex` = ?");
        $state->execute([$_SESSION['steamid'], $current_t->weapon_defindex]);
        $savedskins = $state->fetchAll();

        $is_knife = $selectedweapon == 'weapon_bayonet' || strpos($selectedweapon, 'knife') != 0;
        if($is_knife) {
            $state = $pdo->prepare("SELECT * FROM `wp_player_knife` WHERE `steamid` = ?");
            $state->execute([$_SESSION['steamid']]);
            $savedknifes = $state->fetchAll();
            
            $knife_t = false;
            $knife_ct = false;
            foreach($savedknifes as $saved) {
                if($saved['weapon_team'] == 2) {
                    $knife_t = $saved;
                }
                if($saved['weapon_team'] == 3) {
                    $knife_ct = $saved;
                }
            }
        }


        foreach($savedskins as $saved) {
            if($saved['weapon_team'] == 2) {
                $saved_t = $saved;
            }
            if($saved['weapon_team'] == 3) {
                $saved_ct = $saved;
            }
        }

        foreach($full_skins as $skin) {
            if($saved_t && $saved_t['weapon_defindex'] == $skin->weapon_defindex && $saved_t['weapon_paint_id'] == $skin->paint) {
                $current_t = $skin;
            }
            if($saved_ct && $saved_ct['weapon_defindex'] == $skin->weapon_defindex && $saved_ct['weapon_paint_id'] == $skin->paint) {
                $current_ct = $skin;
            }
        }

        $weapon_info['img'] = [];
        if($current_t) {
            $weapon_info['name'] = explode(' | ', $current_t->paint_name)[0];
            array_push($weapon_info['img'], $current_t->image);
        }
        if($current_ct) {
            if(!isset($weapon_info['name'])) {
                $weapon_info['name'] = explode(' | ', $current_ct->paint_name)[0];
            }
            array_push($weapon_info['img'], $current_ct->image);
        }

        break;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?= GetPrefix(); ?>src/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="<?= GetPrefix(); ?>css/main.css" type="text/css">
    <link rel="stylesheet" href="<?= GetPrefix(); ?>css/skins.css" type="text/css">
    <script src="<?= GetPrefix(); ?>js/skins.js" defer></script>
    <title><?= $translations->website_name; ?> - Skins</title>
</head>
<body <?= $bodyStyle ?? "" ?>>

<div id="loading">
    <span></span>
</div>

<div class="wrapper">
    <div class="container">
        <nav>
            <button class="preview" data-action="toggle_preview">
                <?php
                foreach($weapon_info['img'] as $imgsrc) {
                    echo "<img src='$imgsrc' loading='lazy'>";
                }
                ?>
            </button>
            <div class="info">
                <p><?= $translations->skins->selected_weapon->weapon_selected_label; ?><br><strong>
                    <?= $weapon_info['name']; ?>
                </strong></p>
                <button class="main-btn" data-action="weapon_choose"><?= $translations->skins->selected_weapon->choose_weapon_button; ?></button>
            </div>
        </nav>
        <div class="skins">
            <h3><?= $translations->skins->selected_weapon->select_skin_label; ?></h3>
            <ul>
                <?php
                switch($selectedweapon_type) {
                    case 'gloves':
                        foreach($gloves as $glove) {
                            if($glove->weapon_defindex != $selectedweapon) {continue;}
                            ?>
                            <li>
                                <button class='card <?= $saved_t['weapon_defindex'] == $glove->weapon_defindex && $current_t->paint == $glove->paint || $saved_ct['weapon_defindex'] == $glove->weapon_defindex && $current_ct->paint == $glove->paint?'selected':''; ?>' data-action='weapon_change' data-weapon='<?= $selectedweapon; ?>' data-defindex='<?= $glove->weapon_defindex; ?>' data-paint='<?= $glove->paint == '0' ?'default':$glove->paint; ?>'>
                                    <div class="imgbox">
                                        <img src='<?= $glove->image; ?>' loading='lazy'>
                                    </div>
                                    <span><?= explode('|', $glove->paint_name)[1]; ?></span>
                                    <div class="marks">
                                        <?php
                                        if($saved_t && $current_t && $saved_t['weapon_defindex'] == $glove->weapon_defindex && $current_t->paint == $glove->paint) {
                                            ?>
                                            <input type="radio" name="marks_<?= $glove->paint; ?>" class="terrormark" checked>
                                            <?php
                                        }
                                        if($saved_ct && $current_ct && $saved_ct['weapon_defindex'] == $glove->weapon_defindex && $current_ct->paint == $glove->paint) {
                                            ?>
                                            <input type="radio" name="marks_<?= $glove->paint; ?>" class="counterterrormark" <?= !$saved_t || !$current_t || $saved_t['weapon_defindex'] != $glove->weapon_defindex || $current_t->paint != $glove->paint?'checked':''; ?>>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </button>
                            </li>
                            <?php
                        }
                        break;
                    case 'mvp':
                        foreach($songs as $song) {
                            ?>
                            <li>
                                <button class='card <?= $saved_t['music_id'] == $song->id || $saved_ct['music_id'] == $song->id || !$saved_t && $song->id == 0 || !$saved_ct && $song->id == 0?'selected':''; ?>' data-action='mvp_change' data-id='<?= $song->id == 0?'default':$song->id; ?>'>
                                    <div class="imgbox">
                                        <img src='<?= $song->image; ?>' alt='<?= $song->id; ?>' loading='lazy'>
                                    </div>
                                    <span><?= $song->name; ?></span>
                                    <div class="marks">
                                        <?php
                                        if($saved_t && $saved_t['music_id'] == $song->id) {
                                            ?>
                                            <input type="radio" name="marks_<?= $song->id; ?>" class="terrormark" checked>
                                            <?php
                                        }
                                        if($saved_ct && $saved_ct['music_id'] == $song->id) {
                                            ?>
                                            <input type="radio" name="marks_<?= $song->id; ?>" class="counterterrormark" checked>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </button>
                            </li>
                            <?php
                        }
                        break;
                    case 'agents':
                        foreach($agents as $agent) {
                            if($selectedweapon == 'terrorist' && $agent->team != 2 || $selectedweapon == 'counter-terrorist' && $agent->team != 3) {continue;}
                            ?>
                            <li>
                                <button class='card <?= $saved_t && $saved_t == $agent->model || $saved_ct && $saved_ct == $agent->model || !$saved_t && $selectedweapon == 'terrorist' && $agent->model == 'default' || !$saved_ct && $selectedweapon == 'counter-terrorist' && $agent->model == 'default'?'selected':''; ?>' data-action='agent_change' data-agent='<?= $agent->model; ?>' data-team='<?= $agent->team; ?>'>
                                    <div class="imgbox">
                                        <img src='<?= $agent->image; ?>' alt='<?= $agent->model; ?>' loading='lazy'>
                                    </div>
                                    <span><?= explode('|', $agent->agent_name)[0]; ?></span>
                                </button>
                            </li>
                            <?php
                        }
                        break;
                    default:
                        foreach($full_skins as $skin) {
                            if($skin->weapon_name != $selectedweapon) {continue;}

                            $selected = false;
                            if($is_knife) {
                                if($knife_t && $current_t && $knife_t['knife'] == $skin->weapon_name && $current_t->paint == $skin->paint || $knife_ct && $current_ct && $knife_ct['knife'] == $skin->weapon_name && $current_ct->paint == $skin->paint) {
                                    $selected = true;
                                }else if($skin->weapon_name == 'weapon_knife_default') {
                                    if(!$knife_t || !$knife_ct) {
                                        $selected = true;
                                    }
                                }
                            }else {
                                $selected = $saved_t && $saved_t['weapon_paint_id'] == $skin->paint && !in_array($skin->weapon_name, $ct_only) || $saved_ct && $saved_ct['weapon_paint_id'] == $skin->paint && !in_array($skin->weapon_name, $t_only);
                            }
                            ?>
                            <li>
                                <button class='card <?= $selected?'selected':''; ?>' data-action='weapon_change' data-weapon='<?= $skin->weapon_name; ?>' data-defindex='<?= $skin->weapon_defindex; ?>' data-paint='<?= $skin->paint == '0' ?'default':$skin->paint; ?>'>
                                    <div class="imgbox">
                                        <img src='<?= $skin->image; ?>' alt='<?= $skin->weapon_name; ?>' loading='lazy'>
                                    </div>
                                    <span><?= explode('|', $skin->paint_name)[1]; ?></span>
                                    <div class="marks">
                                        <?php
                                        if(!in_array($skin->weapon_name, $ct_only)) {
                                            if($saved_t && $current_t && $current_t->paint == $skin->paint || $current_t && $current_t->paint == 0 && $skin->paint == 0 && !$is_knife) {
                                            ?>
                                            <input type="radio" name="marks_<?= $skin->paint; ?>" class="terrormark" checked>
                                            <?php
                                        }
                                        }
                                        if(!in_array($skin->weapon_name, $t_only)) {
                                        if($saved_ct && $current_ct && $current_ct->paint == $skin->paint || !$current_ct && $skin->paint == 0 && !$is_knife) {
                                            ?>
                                            <input type="radio" name="marks_<?= $skin->paint; ?>" class="counterterrormark" <?= !$saved_t && !$current_t || $current_t->paint != $skin->paint || in_array($skin->weapon_name, $ct_only)?'checked':''; ?>>
                                            <?php
                                        }
                                        }
                                        ?>
                                    </div>
                                </button>
                            </li>
                            <?php
                        }
                        break;
                }
                ?>
            </ul>
        </div>
    </div>
</div>


</body>
</html>
