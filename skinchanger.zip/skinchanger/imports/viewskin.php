<?php

if(!function_exists("Path")) {
    return;
}

/*************/
/* SteamInfo */
/*************/

try {
    $steamApiUserInfo = file_get_contents("http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=$SteamAPI_KEY&steamids=".$_SESSION['steamid']);
    $UserInfo = json_decode($steamApiUserInfo)->response->players[0];
}catch(Exception $err) {
    header("Refresh:0;");
}

/*************/
/* Languages */
/*************/

$langs = scandir('translation/');
array_shift($langs);
array_shift($langs);

/*****************/
/* WeaponPreview */
/*****************/

$current = false;

$saved_t = false;
$saved_ct = false;

$player_skin = false;

$selectedpaint = 0;
if(Path(2) != 'default') {$selectedpaint = Path(2);}

$type = GetWeaponType(Path(1));
if($type == 'gloves') {
    if(Path(2) == 'default') {
        $selectedpaint = 'default';
    }
    
    foreach($gloves as $key=>$glove) {
        if($glove->weapon_defindex == Path(1)
        && $glove->paint == $selectedpaint) {
            $current = $glove;
            break;
        }
    }
}else if($type == 'agents') {
    Path(1) == 'terrorist' ? $team = 2:$team = 3;

    if(Path(2) == 'default') {
        $selectedpaint = 'default';
    }

    $modelagent = str_replace('-', '/', $selectedpaint);
    foreach($agents as $key=>$agent) {
        if($agent->team == $team
        && $agent->model == $modelagent) {
            $current = $agent;
            break;
        }
    }
}else if($type == 'mvp') {
    foreach($songs as $key=>$mvp) {
        if($mvp->id == $selectedpaint) {
            $current = $mvp;
            break;
        }
    }
}else {
    foreach($full_skins as $key=>$skin) {
        if($skin->weapon_name == Path(1)
        && $skin->paint == $selectedpaint) {
            $current = $skin;
            break;
        }
    }
}

if(!$current) {
    header("Location: ".GetPrefix());
    exit;
}

switch($type) {
    case 'gloves':
        $weapon = [
            'name' => $current->paint_name,
            'index' => $current->weapon_defindex,
            'paint' => $current->paint
        ];

        $query = $pdo->prepare("SELECT * FROM `wp_player_gloves` WHERE `steamid` = ? AND `weapon_defindex` = ?");
        $query->execute([$_SESSION['steamid'], $current->weapon_defindex]);
        $savedgloves = $query->fetchAll();
        
        foreach($savedgloves as $saved) {
            if($saved['weapon_team'] == 1) {
                $temp_t = $saved;
            }
            if($saved['weapon_team'] == 2) {
                $temp_ct = $saved;
            }
        }

        $query = $pdo->prepare("SELECT * FROM `wp_player_skins` WHERE `steamid` = ? AND `weapon_defindex` = ?");
        $query->execute([$_SESSION['steamid'], $current->weapon_defindex]);
        $savedskins = $query->fetchAll();
        
        foreach($savedskins as $saved) {
            if($saved['weapon_paint_id'] == $selectedpaint && $saved['weapon_team'] == 1) {
                $saved_t = $saved;
            }
            if($saved['weapon_paint_id'] == $selectedpaint && $saved['weapon_team'] == 2) {
                $saved_ct = $saved;
            }
        }

        $weapon['t'] = false;
        $weapon['ct'] = false;
        if($saved_t) {
            $weapon['t'] = true;
            $player_skin = $saved_t;
        }
        if($saved_ct) {
            $weapon['ct'] = true;

            if(!$player_skin) {
                $player_skin = $saved_ct;
            }
        }

        if($current->paint == 'ct') {
            $weapon['t'] = null;
        }
        if($current->paint == 't') {
            $weapon['ct'] = null;
        }
        
        break;
    case 'agents':
        $weapon = [
            'name' => $current->agent_name,
            'index' => $current->model
        ];

        $query = $pdo->prepare("SELECT * FROM `wp_player_agents` WHERE `steamid` = ?");
        $query->execute([$_SESSION['steamid']]);
        
        $result = $query->fetch();
        
        if($current->team == 2) {
            if($result && $result['agent_t'] == $current->model) {
                $weapon['t'] = true;
            }else {
                $weapon['t'] = false;
            }
        }else if($current->team == 3) {
            if($result && $result['agent_ct'] == $current->model) {
                $weapon['ct'] = true;
            }else {
                $weapon['ct'] = false;
            }
        }
        break;
    case 'mvp':
        $weapon = [
            'name' => $current->name,
            'index' => $current->id
        ];

        $query = $pdo->prepare("SELECT * FROM `wp_player_music` WHERE `steamid` = ? AND `music_id` = ?");
        $query->execute([$_SESSION['steamid'], $current->id]);

        $weapon['t'] = false;
        $weapon['ct'] = false;

        $results = $query->fetchAll();
        foreach($results as $res) {
            if($res['weapon_team'] == 0 || $res['weapon_team'] == 1) {
                $weapon['t'] = true;
            }
            if($res['weapon_team'] == 0 || $res['weapon_team'] == 2) {
                $weapon['ct'] = true;
            }
        }
        break;
    default:
        $weapon = [
            'name' => $current->paint_name,
            'index' => $current->weapon_defindex,
            'paint' => $current->paint,
            'weapon_name' => $current->weapon_name
        ];

        $query = $pdo->prepare("SELECT * FROM `wp_player_skins` WHERE `steamid` = ? AND `weapon_defindex` = ? AND `weapon_paint_id` = ?");
        $query->execute([$_SESSION['steamid'], $current->weapon_defindex, $current->paint]);

        if(!in_array($current->weapon_name, $t_only)) {
            $weapon['ct'] = false;
        }
        if(!in_array($current->weapon_name, $ct_only)) {
            $weapon['t'] = false;
        }

        $player_skins = $query->fetchAll();
        if($player_skins) {
            foreach($player_skins as $skin) {
                if(!in_array($current->weapon_name, $ct_only)) {
                    if($skin['weapon_team'] == 0 || $skin['weapon_team'] == 1) {
                        $saved_t = $skin;
                        $weapon['t'] = true;
                    }
                }
                if(!in_array($current->weapon_name, $t_only)) {
                    if($skin['weapon_team'] == 0 || $skin['weapon_team'] == 2) {
                        $saved_ct = $skin;
                        $weapon['ct'] = true;
                    }
                }
            }
        }

        $player_skin = $player_skins[0] ?? false;

        break;
}

if(isset($player_skin) && $player_skin
&& $player_skin['weapon_wear'] != 0
&& $player_skin['weapon_wear'] != 0.07
&& $player_skin['weapon_wear'] != 0.15
&& $player_skin['weapon_wear'] != 0.38
&& $player_skin['weapon_wear'] != 0.45) {
    $custom_wear = $player_skin['weapon_wear'];
}


$stickers_loop = false;
if(isset($player_skin) && $player_skin) {
    if($player_skin['weapon_sticker_0']) {
        $sticker0 = explode(';', $player_skin['weapon_sticker_0']);
        $stickers_loop = true;
    }
    if($player_skin['weapon_sticker_1']) {
        $sticker1 = explode(';', $player_skin['weapon_sticker_1']);
        $stickers_loop = true;
    }
    if($player_skin['weapon_sticker_2']) {
        $sticker2 = explode(';', $player_skin['weapon_sticker_2']);
        $stickers_loop = true;
    }
    if($player_skin['weapon_sticker_3']) {
        $sticker3 = explode(';', $player_skin['weapon_sticker_3']);
        $stickers_loop = true;
    }
    if($player_skin['weapon_sticker_4']) {
        $sticker4 = explode(';', $player_skin['weapon_sticker_4']);
        $stickers_loop = true;
    }

    if($player_skin['weapon_keychain']) {
        $keychain0 = explode(';', $player_skin['weapon_keychain']);
        foreach($keychains as $keychain) {
            if($keychain->id == $keychain0[0]) {
                $keychain0_info = $keychain;
                break;
            }
        }
    }
}

if($stickers_loop) {
    foreach($stickers as $sticker) {
        if(isset($sticker0) && $sticker->id == $sticker0[0]) {
            $sticker0_info = $sticker;
        }
        if(isset($sticker1) && $sticker->id == $sticker1[0]) {
            $sticker1_info = $sticker;
        }
        if(isset($sticker2) && $sticker->id == $sticker2[0]) {
            $sticker2_info = $sticker;
        }
        if(isset($sticker3) && $sticker->id == $sticker3[0]) {
            $sticker3_info = $sticker;
        }
        if(isset($sticker4) && $sticker->id == $sticker4[0]) {
            $sticker4_info = $sticker;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?= GetPrefix(); ?>src/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="<?= GetPrefix(); ?>css/main.css" type="text/css">
    <link rel="stylesheet" href="<?= GetPrefix(); ?>css/skins.css" type="text/css">
    <link rel="stylesheet" href="<?= GetPrefix(); ?>css/view.css" type="text/css">
    <script src="<?= GetPrefix(); ?>js/skins.js" defer></script>
    <script type="importmap">
        {
            "imports": {
            "three": "https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js",
            "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.170.0/examples/jsm/"
            }
        }
    </script>
    <script>
        let usethreejs = <?= $Website_UseThreejs?"true":"false"; ?>;
        let modelpath = false;texturepath = false,legacy = <?= empty($current->legacy_model) ? "false": $current->legacy_model; ?>;
        <?php
        if($Website_UseThreejs && isset($current->threejsmodel)) {
        ?>
        modelpath = "<?= $current->threejsmodel; ?>";
        <?php
        }
        if($Website_UseThreejs && isset($current->texture) && isset($current->texture_metal)) {
        ?>
        texturepath = ["<?= $current->texture; ?>", "<?= $current->texture_metal; ?>"];
        <?php
        }
        ?>
        const Prefix = "<?= GetPrefix(); ?>";
        const currenttype = "<?= $type; ?>";

        let saved_t = `<?= $saved_t?json_encode($saved_t):'0'; ?>`, saved_ct = `<?= $saved_ct?json_encode($saved_ct):'0'; ?>`;
    </script>
    <script src="<?= GetPrefix(); ?>js/weaponviewer.js" type="module" defer></script>
    <title><?= $translations->website_name; ?> - Skins</title>
</head>
<body <?= $bodyStyle ?? "" ?>>

<div id="loading">
    <span></span>
</div>

<div id="messages"></div>

<div class="wrapper mainbox" data-index="<?= $weapon['index'] ?>" <?= isset($weapon['paint'])?'data-paint="'.$weapon['paint'].'"':''; ?> <?= isset($weapon['weapon_name'])?'data-name="'.$weapon['weapon_name'].'"':''; ?>>
    <div id="viewselect">
        <div class="titlebox">
            <button class="viewselect_return" <?= $translations->invert_direction?'style="right: unset;left: 120%;"':''; ?>>^</button>
            <h2 class="title" data-prefix="<?= $translations->skins->view_skin->select; ?>"></h2>
        </div>
        <div class="input">
            <input type="text" placeholder="<?= $translations->skins->view_skin->search; ?>" data-prefix="<?= $translations->skins->view_skin->search; ?>">
        </div>
        <ul></ul>
    </div>

    <header>
        <h2><?= $weapon['name']; ?></h2>
    </header>
    <div id="threejsArea"></div>
    <div id="previewImg">
        <img src="<?= $current->image; ?>">
    </div>
    <div id="settings" <?= $translations->invert_direction?'style="animation: slideLeft 1s forwards;"':''; ?>>
        <div class="title">
            <a href="<?= GetPrefix(); ?>skins/<?= Path(1); ?>/" <?= $translations->invert_direction?'style="right: unset;left: 120%;"':''; ?>><</a>
            <span><?= $translations->skins->view_skin->title; ?>
                <svg viewBox="0 0 48 48"><path d="M36.9,12c-0.4-1.7-2-3-3.9-3s-3.4,1.3-3.9,3H2v2h27.1c0.4,1.7,2,3,3.9,3s3.4-1.3,3.9-3H46v-2H36.9z M33,15   c-1.1,0-2-0.9-2-2s0.9-2,2-2s2,0.9,2,2S34.1,15,33,15z"/><path d="M33,31c-1.9,0-3.4,1.3-3.9,3H2v2h27.1c0.4,1.7,2,3,3.9,3s3.4-1.3,3.9-3H46v-2h-9.1C36.4,32.3,34.9,31,33,31z M33,37   c-1.1,0-2-0.9-2-2s0.9-2,2-2s2,0.9,2,2S34.1,37,33,37z"/><path d="M15,20c-1.9,0-3.4,1.3-3.9,3H2v2h9.1c0.4,1.7,2,3,3.9,3s3.4-1.3,3.9-3H46v-2H18.9C18.4,21.3,16.9,20,15,20z M15,26   c-1.1,0-2-0.9-2-2c0-1.1,0.9-2,2-2s2,0.9,2,2C17,25.1,16.1,26,15,26z"/></svg>
            </span>
        </div>
        <div class="input" id="preset" <?= !$saved_t || !$saved_ct?'style="display:none;"':''; ?>>
            <label for="preset"><?= $translations->skins->view_skin->team; ?></label>
            <div class="marks">
                <input type="radio" name="preset" class="terrormark" checked>
                <input type="radio" name="preset" class="counterterrormark">
            </div>
        </div>
        <?php
        if($type != 'agents' && $type != 'mvp' && $current->paint != 'ct' && $current->paint != 't' && $selectedpaint != 'default') {
        if($selectedpaint != 0 && $type != 'knifes' || $type == 'knifes') {
        ?>
        <div class="input" id="wear">
            <label for="wear"><?= $translations->skins->view_skin->wear->label; ?></label>
            <select>
                <option value="0" <?= $player_skin && $player_skin['weapon_wear'] == 0?'selected="selected"':''; ?>><?= $translations->skins->view_skin->wear->factory_new; ?></option>
                <option value="0.07" <?= $player_skin && $player_skin['weapon_wear'] == 0.07?'selected="selected"':''; ?>><?= $translations->skins->view_skin->wear->minimal_wear; ?></option>
                <option value="0.15" <?= $player_skin && $player_skin['weapon_wear'] == 0.15?'selected="selected"':''; ?>><?= $translations->skins->view_skin->wear->field_tested; ?></option>
                <option value="0.38" <?= $player_skin && $player_skin['weapon_wear'] == 0.38?'selected="selected"':''; ?>><?= $translations->skins->view_skin->wear->well_worn; ?></option>
                <option value="0.45" <?= $player_skin && $player_skin['weapon_wear'] == 0.45?'selected="selected"':''; ?>><?= $translations->skins->view_skin->wear->battle_scarred; ?></option>
                <option value="custom" <?= isset($custom_wear)?'selected="selected"':''; ?>><?= $translations->skins->view_skin->wear->custom; ?></option>
            </select>
            <input type="range" id="customwear" min="0" max="0.99" value="<?= isset($custom_wear)?$custom_wear:'0'; ?>" data-val="<?= isset($custom_wear)?$custom_wear:'0'; ?>" step="0.01"
            oninput="this.style.setProperty('--fill-precent', `${this.value / this.max * 100}%`);this.dataset.val = this.value;"
            style="--fill-precent: <?= isset($custom_wear)?(($custom_wear/1)*100).'%':'0'; ?>;">
        </div>
        <div class="input" id="seed">
            <label for="seed"><?= $translations->skins->view_skin->seed; ?></label>
            <div class="box">
                <input type="checkbox" oninput="this.checked?this.nextElementSibling.disabled=false:this.nextElementSibling.disabled=true;" <?= $player_skin['weapon_seed'] ?? 0 > 0?'checked':''; ?>>
                <input type="number" placeholder="1 - 1000" min="1" max="1000" <?= $player_skin['weapon_seed'] ?? 0 > 0?"value='".$player_skin['weapon_seed']."'":'disabled'; ?>>
            </div>
        </div>
        <div class="input" id="nametag">
            <label for="nametag"><?= $translations->skins->view_skin->nametag; ?></label>
            <div class="box">
                <input type="checkbox" oninput="this.checked?this.nextElementSibling.disabled=false:this.nextElementSibling.disabled=true;" <?= !is_null($player_skin['weapon_nametag'] ?? null)?'checked':''; ?>>
                <input type="text" placeholder="<?= $translations->skins->view_skin->nametag; ?>" <?php if($player_skin && !is_null($player_skin['weapon_nametag'])){echo 'value="'.$player_skin['weapon_nametag'].'"';}else {echo 'disabled';} ?>>
            </div>
        </div>
        <?php
        if($type != 'gloves') {
        ?>
        <div class="box" id="stattrak">
            <div class="input">
                <label for="stattrak"><?= $translations->skins->view_skin->stattrak->label; ?></label>
                <div class="box">
                    <input type="checkbox" oninput="this.checked?document.querySelector('#stattrak p').style.opacity = 1:document.querySelector('#stattrak p').style.opacity = 0.3;" <?= $player_skin['weapon_stattrak'] ?? false?'checked':''; ?>>
                </div>
            </div>
            <div class="input">
                <label for="stattrak"><?= $translations->skins->view_skin->stattrak->label_kills; ?></label>
                <p <?= $player_skin['weapon_stattrak'] ?? false?'style="opacity:1;color:white;"':''; ?>><?= $player_skin['weapon_stattrak'] ?? false?$player_skin['weapon_stattrak_count'] ?? false:'/'; ?></p>
            </div>
        </div>
        <?php
        if($type != 'knifes') {
        ?>
        <div class="addons">
            <div class="box-col">
                <label for="stickers"><?= $translations->skins->view_skin->stickers; ?></label>
                <div class="stickers">
                    <button <?= isset($sticker0_info)?'data-id="'.$sticker0[0].'" title="'.$sticker0_info->name.'"':''; ?>><?= isset($sticker0_info)?'<img src="'.$sticker0_info->image.'">':'+';?></button>
                    <button <?= isset($sticker1_info)?'data-id="'.$sticker1[0].'" title="'.$sticker1_info->name.'"':''; ?>><?= isset($sticker1_info)?'<img src="'.$sticker1_info->image.'">':'+';?></button>
                    <button <?= isset($sticker2_info)?'data-id="'.$sticker2[0].'" title="'.$sticker2_info->name.'"':''; ?>><?= isset($sticker2_info)?'<img src="'.$sticker2_info->image.'">':'+';?></button>
                    <button <?= isset($sticker3_info)?'data-id="'.$sticker3[0].'" title="'.$sticker3_info->name.'"':''; ?>><?= isset($sticker3_info)?'<img src="'.$sticker3_info->image.'">':'+';?></button>
                    <button <?= isset($sticker4_info)?'data-id="'.$sticker4[0].'" title="'.$sticker4_info->name.'"':''; ?>><?= isset($sticker4_info)?'<img src="'.$sticker4_info->image.'">':'+';?></button>
                </div>
            </div>
            <div class="box-col">
                <label for="keychains"><?= $translations->skins->view_skin->keychains; ?></label>
                <div class="keychains">
                    <button <?= isset($keychain0_info)?'data-id="'.$keychain0[0].'" title="'.$keychain0_info->name.'"':''; ?>><?= isset($keychain0_info)?'<img src="'.$keychain0_info->image.'">':'+';?></button>
                </div>
            </div>
        </div>
        <?php
        }
        }
        }
        }
        ?>
        <div class="apply">
            <?php
            if(isset($weapon['t'])) {
            ?>
            <button class="main-btn terror<?= $weapon['t'] ? ' applied': ''; ?>"><?= $translations->skins->view_skin->apply->terror; ?></button>
            <?php
            }
            if(isset($weapon['ct'])) {
            ?>
            <button class="main-btn counter-terror<?= $weapon['ct'] ? ' applied': ''; ?>"><?= $translations->skins->view_skin->apply->counterterror; ?></button>
            <?php
            }
            ?>
        </div>
    </div>
</div>