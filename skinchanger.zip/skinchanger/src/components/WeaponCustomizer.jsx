import React, { useRef, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls, useGLTF, Decal } from "@react-three/drei";
import { DndProvider, useDrag, useDrop } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";

// Список доступних наліпок
const STICKERS = [
  { id: 1, name: "Sticker 1", img: "/stickers/sticker1.png" },
  { id: 2, name: "Sticker 2", img: "/stickers/sticker2.png" },
];

// Компонент для drag наліпки
function StickerItem({ sticker }) {
  const [{ isDragging }, drag] = useDrag({
    type: "STICKER",
    item: { ...sticker },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  });
  return (
    <img
      ref={drag}
      src={sticker.img}
      alt={sticker.name}
      style={{
        width: 64,
        opacity: isDragging ? 0.5 : 1,
        cursor: "grab",
        margin: 8,
      }}
    />
  );
}

// 3D-модель зброї з наліпками
function WeaponModel({ stickers, onDropSticker }) {
  const { scene } = useGLTF("/assets/models/weapon.glb");
  const { camera, gl } = useThree();
  const meshRef = useRef();

  // Drop-область для Canvas
  const [, drop] = useDrop({
    accept: "STICKER",
    drop: (item, monitor) => {
      // Отримати координати миші
      const clientOffset = monitor.getClientOffset();
      const rect = gl.domElement.getBoundingClientRect();
      const x = ((clientOffset.x - rect.left) / rect.width) * 2 - 1;
      const y = -((clientOffset.y - rect.top) / rect.height) * 2 + 1;

      // Перетворити у 3D-координати (на поверхню зброї)
      // Для простоти — фіксована z
      const position = [x, y, 0.1];
      onDropSticker(item, position);
    },
  });

  return (
    <group ref={drop}>
      <primitive object={scene} />
      {stickers.map((sticker, idx) => (
        <Decal
          key={idx}
          position={sticker.position}
          scale={0.2}
          rotation={[0, 0, 0]}
          map={sticker.texture}
        />
      ))}
    </group>
  );
}

export default function WeaponCustomizer() {
  const [stickers, setStickers] = useState([]);

  // Додаємо наліпку на зброю
  const handleDropSticker = (sticker, position) => {
    const texture = new window.THREE.TextureLoader().load(sticker.img);
    setStickers((prev) => [
      ...prev,
      { ...sticker, position, texture },
    ]);
  };

  // Зберегти у localStorage
  const handleSave = () => {
    localStorage.setItem("stickers", JSON.stringify(stickers.map(s => ({
      ...s,
      texture: undefined // не зберігаємо texture-об'єкт
    }))));
    alert("Збережено!");
  };

  // Завантажити з localStorage
  React.useEffect(() => {
    const saved = localStorage.getItem("stickers");
    if (saved) {
      const arr = JSON.parse(saved);
      arr.forEach(s => {
        s.texture = new window.THREE.TextureLoader().load(s.img);
      });
      setStickers(arr);
    }
  }, []);

  return (
    <DndProvider backend={HTML5Backend}>
      <div style={{ display: "flex" }}>
        <div style={{ width: 100 }}>
          {STICKERS.map((s) => (
            <StickerItem key={s.id} sticker={s} />
          ))}
        </div>
        <div style={{ width: 600, height: 400, border: "1px solid #ccc" }}>
          <Canvas camera={{ position: [0, 0, 3] }}>
            <ambientLight />
            <WeaponModel stickers={stickers} onDropSticker={handleDropSticker} />
            <OrbitControls />
          </Canvas>
        </div>
        <button onClick={handleSave} style={{ marginLeft: 16 }}>Зберегти</button>
      </div>
    </DndProvider>
  );
}