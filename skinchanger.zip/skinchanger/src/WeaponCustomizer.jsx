import React, { useState, useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, useGLTF } from '@react-three/drei';
import { TextureLoader } from 'three';
import { useLoader } from '@react-three/fiber';
import skins from './data/skins.json';

function WeaponModel({ url, textureUrl }) {
  const { scene } = useGLTF(url);
  const texture = textureUrl ? useLoader(TextureLoader, textureUrl) : null;

  useEffect(() => {
    if (texture) {
      scene.traverse((child) => {
        if (child.isMesh) {
          child.material.map = texture;
          child.material.needsUpdate = true;
        }
      });
    }
  }, [scene, texture]);

  return <primitive object={scene} />;
}

export default function WeaponCustomizer() {
  const [selectedSkin, setSelectedSkin] = useState(skins[0]);

  return (
    <div>
      <select onChange={e => setSelectedSkin(skins[e.target.value])}>
        {skins.map((skin, idx) => (
          <option value={idx} key={skin.paint_name}>{skin.paint_name}</option>
        ))}
      </select>
      <Canvas camera={{ position: [0, 0, 5] }}>
        <ambientLight />
        <OrbitControls />
        <WeaponModel
          url={selectedSkin.threejsmodel}
          textureUrl={selectedSkin.texture}
        />
      </Canvas>
    </div>
  );
}